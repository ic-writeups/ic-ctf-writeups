#!/usr/bin/env python3
from pwn import *

# El valor que se vio en RBP
rbp_value = 0x636161706361616f

# Encontramos el offset
offset_rbp = cyclic_find(rbp_value)

print(f"Offset hasta RBP: {offset_rbp}")