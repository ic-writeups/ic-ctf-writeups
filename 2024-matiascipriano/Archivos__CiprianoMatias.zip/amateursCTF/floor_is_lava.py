import ctypes
import ctypes.util
import sys

libc = ctypes.CDLL(ctypes.util.find_library("c"))
libc.srand.argtypes = [ctypes.c_uint]
libc.srand.restype = None
libc.rand.argtypes = []
libc.rand.restype = ctypes.c_int

# lleno con los flips segun las coordenadas del script anterior
TARGET_FLIPS = {
    (0, 1), (0, 3), (0, 5), (0, 6),
    (1, 1), (1, 2), (1, 3), (1, 5),
    (2, 4), (2, 5),
    (3, 0), (3, 3), (3, 4), (3, 6), (3, 7),
    (4, 0), (4, 1), (4, 2), (4, 3), (4, 6),
    (5, 4), (5, 5), (5, 6),
    (6, 2), (6, 3), (6, 4),
    (7, 2), (7, 3)
}

#los 21 bytes cifrados de 'unk_4020'
FLAG_CIFRADA = bytearray(b'\xD6\xB2\x05\x20\x95\x5B\x1A\xBE\x4E\x70\x5F\x60\xF9\x74\x51\xEE\x69\x56\x8C\x6A\xC1')

# segun el codigo assembler cada letra escribe 0 1 2 3
MOVE_VALUES = {'w': 0, 'a': 1, 's': 2, 'd': 3}

# -----------------------------------------------------------------
# 4. Funciones de Replicación (Las Fases del Binario)
# -----------------------------------------------------------------

def calculate_seed(moves_list):
    """ Aca se calcula el final_seed."""
    
    # replicamos 'mov [rbp+var_10], 0'
    var_10 = 0
    
    # se replica (cmp [rbp+var_18], 1Bh)
    # que se ejecuta 28 veces, una por cada movimiento.
    for move_char in moves_list:
        move_value = MOVE_VALUES[move_char]
        
        # --- loc_13D7 ---
        val = var_10
        # 'lea rcx, ds:0[rax*4]'
        rcx = (val * 4) & 0xFFFFFFFFFFFFFFFF
        # 'movzx eax, byte ptr [rax+rdx]' (donde el byte es el 'move_value')
        byte = move_value
        
        # 'or rax, rcx'
        nuevo_val = byte | rcx
        # 'mov [rbp+var_10], rax'
        var_10 = nuevo_val & 0xFFFFFFFFFFFFFFFF

    # calcular de semilla final
    # 'mov edx, [rax]' (32 bits de abajo)
    lower_32 = var_10 & 0xFFFFFFFF
    # 'mov eax, [rax+4]' (32 bits de arriba)
    upper_32 = (var_10 >> 32) & 0xFFFFFFFF
    
    # 'xor eax, edx'
    final_seed = upper_32 ^ lower_32
    return final_seed

def decrypt_flag(final_seed, encrypted_data):
    """ Descriframos la bandera """
    
    libc.srand(final_seed)
    decrypted = bytearray(encrypted_data)
    
    # cmp eax, 14h
    # que se ejecuta 21 veces (0 a 20).
    for k in range(21):
        # 'call _rand' y 'movzx ecx, al'
        rand_byte = libc.rand() & 0xFF
        
        # 'xor eax, edx' y 'mov [rax+rdx], cl'
        decrypted[k] = encrypted_data[k] ^ rand_byte
    
    return decrypted

solution = None

def solve(current_path, current_X, current_Y, visited_coords):
    """
    Función recursiva que busca un camino de 28 pasos.
    current_path: Lista de movimientos (ej. ['w', 'w', 'a'])
    current_X, current_Y: Coordenadas actuales
    visited_coords: Un 'set' de (Y,X) que ya hemos volteado.
    """
    global solution
    if solution: # si ya encontramos la bandera, paramos toda la búsqueda.
        return

    # si el camino tiene 28 movimientos, hemos completado la Fase 1.
    if len(current_path) == 28:
        # cuando se hagan los 28 pasos, se prueba la semilla
        final_seed = calculate_seed(current_path)
        flag = decrypt_flag(final_seed, FLAG_CIFRADA)
        
        try:
            flag_str = flag.decode('utf-8')
						# si la bandera se puede imprimir es porque encontre la semilla
            if flag_str.isprintable():
                print(f"[+] ¡ÉXITO! Semilla: {hex(final_seed)}")
                print(f"    Camino: {''.join(current_path)}")
                solution = (flag_str, ''.join(current_path))
        except UnicodeDecodeError:
            pass # no se puede imprimir, no es la correcta
        
        return

    moves_to_try = [
        ('w', current_X, current_Y - 1), # (char, new_X, new_Y)
        ('a', current_X - 1, current_Y),
        ('s', current_X, current_Y + 1),
        ('d', current_X + 1, current_Y)
    ]
    
    for move_char, next_X, next_Y in moves_to_try:
        
        # replico la lógica 'and eax, 7' de 'loc_12EB'
        # que envuelve las coordenadas en una cuadrícula de 8x8.
        flip_Y = next_Y & 7
        flip_X = next_X & 7
        coord_to_check = (flip_Y, flip_X)
        
        # la coordenada esta en nuestro mapa?
        # ya la visitamos? (para no volvearla dos veces)
        if (coord_to_check in TARGET_FLIPS) and (coord_to_check not in visited_coords):
						# movimiento valido, marco visitado
            visited_coords.add(coord_to_check)
            
            # se continua desde el nuevo punto
            solve(current_path + [move_char], next_X, next_Y, visited_coords)
            
            # limpieza de 'visitados' para que otra ruta pueda intentarlo.
            visited_coords.remove(coord_to_check)

print(" iniciando solver...")
print(f"    Buscando un camino de 28 pasos que visite {len(TARGET_FLIPS)} bits.")

# coordenadas iniciales X,Y son 0,0.
START_X = 0
START_Y = 0

solve([], START_X, START_Y, set()) # camino vacio

print("\n" + "="*50)
if solution:
    flag, path = solution
    print(f"\n  Bandera: amateursCTF{{{flag}}}")
else:
    print("  El solver falló.")
    print("  Verificar las coordenadas (Y,X) o las coords iniciales (X,Y).")