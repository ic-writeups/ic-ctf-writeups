import ctypes
import ctypes.util
import sys

# libreria glibc
libc = ctypes.CDLL(ctypes.util.find_library("c"))
libc.srand.argtypes = [ctypes.c_uint]
libc.srand.restype = None
libc.rand.argtypes = []
libc.rand.restype = ctypes.c_int

# Datos iniciales del unc_4010
start_buffer = bytearray(b'\x8B\xC9\x92\x08\xF9\x91\xD6\xC8')

print("calculando el buffer 'objetivo' de rand()...")

target_buffer = bytearray(8)

# itera de 0 a 7 (8 veces).
for i in range(8):
    # assembler (imul eax, 1337h / sub eax, 21524111h).
    # '& 0xFFFFFFFF' desbordamiento de 32 bits de los registros (eax).
    seed = ((i * 0x1337) - 0x21524111) & 0xFFFFFFFF
    
    libc.srand(seed)
    # tomar el menos significativo (como hacía 'movzx edx, al').
    rand_byte = libc.rand() & 0xFF
    
    # guardar byte objetivo
    target_buffer[i] = rand_byte

print(f"    ... Buffer Inicial: {start_buffer.hex()}")
print(f"    ... Buffer Objetivo: {target_buffer.hex()}")

# calcular el mapa a flipear
print("\ncalculando mapa")

# "calculadora de diferencias de bits".
# 0 ^ 0 = 0 (Sin cambio)
# 1 ^ 1 = 0 (Sin cambio)
# 0 ^ 1 = 1 (¡Diferencia! Se necesita un flip)
# 1 ^ 0 = 1 (¡Diferencia! Se necesita un flip)
flip_map = bytearray(8)
for i in range(8):
    flip_map[i] = start_buffer[i] ^ target_buffer[i]

print(f"    ... Mapa de Flips (HEX): {flip_map.hex()}")

# imprimir el puzzle en formato (Y, X)
print("\n[+] ¡PUZZLE A RESOLVER!")
print("    Debes encontrar una secuencia de 28 movimientos ('w','a','s','d')")
print("    que voltee (visite) exactamente los siguientes bits (Y, X):")

total_flips = 0
#por cada byte en Y
for y_coord in range(8):
    byte_val = flip_map[y_coord]
    if byte_val == 0:
        continue # si el byte es 0, no hay bits que flipear
        
    # iteramos por CADA BIT de ese byte (coordenada X).
    for x_coord in range(8):
        # (byte_val >> x_coord) desplaza el bit X a la posición 0.
        # '& 1' comprueba si ese bit es 1.
        if (byte_val >> x_coord) & 1:
            # si es 1, significa que (Y, X) es una coordenada
            # que necesita ser volteada.
            print(f"    * Voltear bit en (Y={y_coord}, X={x_coord})")
            total_flips += 1

print(f"\n    Total de bits a voltear: {total_flips}")
print("=================================================================")