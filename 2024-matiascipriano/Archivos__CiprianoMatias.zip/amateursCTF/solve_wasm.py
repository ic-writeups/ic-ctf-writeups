#!/usr/bin/env python3
import z3
import re

s = z3.Solver()

# 43 variables de 32 bits, cada char de la flag.
# se usa 32-bits porque es lo que usa WASM para la matematica (i32)
flag = [z3.BitVec(f'f_{i}', 32) for i in range(43)]

# cada char tiene que estar entre 32 y 126 (ASCII legible)
for f in flag:
    s.add(z3.And(f >= 32, f <= 126))

# se lee el archivo con todas las instrucciones
with open('module.wat', 'r') as f:
    wat_content = f.read()

# tomamos todo entre '(func (;0;) ... (result i32)' y el ) que cierra la función
func_body_match = re.search(r'\(func \(;0;\).*\(result i32\)(.*)\(memory \(;0;\) 1\)', wat_content, re.DOTALL)
lines = func_body_match.group(1).strip().split('\n')
stack = []

# recorremos las lineas
for line in lines:
    line = line.strip()
    parts = line.split()
    if not parts:
        continue

    op = parts[0]

    try:
        if op == "i32.const":
            val = int(parts[1].replace(')', '')) # si es el i32.const final le saco el )
            stack.append(val)
        elif op == "i32.load8_u":
            index = stack.pop()
            stack.append(flag[index])
        elif op == "i32.add":
            v2, v1 = stack.pop(), stack.pop()
            stack.append(v1 + v2)
        elif op == "i32.sub":
            v2, v1 = stack.pop(), stack.pop()
            stack.append(v1 - v2)
        elif op == "i32.mul":
            v2, v1 = stack.pop(), stack.pop()
            stack.append(v1 * v2)
        elif op == "i32.xor":
            v2, v1 = stack.pop(), stack.pop()
            stack.append(v1 ^ v2)
        elif op == "i32.and":
            v2, v1 = stack.pop(), stack.pop()
            stack.append(v1 & v2)
        elif op == "i32.or":
            v2, v1 = stack.pop(), stack.pop()
            stack.append(v1 | v2)
        elif op == "i32.ne":
            # Aca esta la manteca
            # el 'if' siguiente falla y hace un return 0 si esto es true (no igual)
            # por lo que se fuerza un false (igual)

            v_const = stack.pop() # el valor constante
            v_expr = stack.pop()  # la expresion calculada

            # aca le decimos que tiene que tienen que ser iguales si o si a las reglas de z3
            s.add(v_expr == v_const)

            # simulamos el push que hace 132.ne al stack despues de evaluar (0 o 1)
            stack.append(z3.BitVecVal(0, 32)) # empujo un cero

        elif op == "if":
            stack.pop() # cuando aparece un if consumo lo que guarde en stack de i32.ne

        elif op == "return" or op == "end":
            pass # esto no import seguimos parseando

    except Exception as e:
        print(f"Error procesando la línea: {line}")
        print(f"Estado del stack: {stack}")
        print(f"Excepción: {e}")
        exit(1)

# se busca la flag
print("Buscando la flag... espere que tarda")
if s.check() == z3.sat:
    m = s.model()
    result = [0] * 43
    # se reconstruye la flag del modelo
    for f_var in flag:
        var_name = str(f_var)
        var_index = int(var_name.split('_')[1])
        result[var_index] = m[f_var].as_long()

    flag_str = "".join(map(chr, result))
    print(f"FLAG: {flag_str}")
else:
    print("Error: No funciono, dedicate a vender panchos.")
