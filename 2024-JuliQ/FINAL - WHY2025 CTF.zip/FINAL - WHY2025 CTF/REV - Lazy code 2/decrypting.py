#!/usr/bin/env python3

encrypted_flag = bytearray("* -+7.\x7f*(-x}z(-).()*{-y({u().|{/x\x7f\x7f{y1L".encode('latin1'))

xors = [
    23,    # 0x17
    43,    # 0x2B
    87,    # 0x57
    111,   # 0x6F
    122,   # 0x7A
    0,     # 0x00
    33,    # 0x21
    45,    # 0x2D
    29,    # 0x1D
    103,   # 0x67
    43,    # 0x2B
    86,    # 0x56
    22,    # 0x16
    99,    # 0x63
    91,    # 0x5B
    103,   # 0x67
    56,    # 0x38
    29,    # 0x1D
    11,    # 0x0B
    10,    # 0x0A
    3,     # 0x03
    112,   # 0x70
    71,    # 0x47
    18,    # 0x12
    54,    # 0x36
    12,    # 0x0C
    99     # 0x63
]


for i in range(1, 1001):
    key = xors[i % 27]
    for j in range(len(encrypted_flag)):
        encrypted_flag[j] ^= key


flag = encrypted_flag.decode('latin1').split('\x00')[0]
print(f"Decrypted flag: {flag}")


# flag{b3fda416daebdef7a5d79deb07c43375}