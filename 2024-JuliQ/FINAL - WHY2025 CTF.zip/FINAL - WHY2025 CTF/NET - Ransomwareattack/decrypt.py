#!/usr/bin/env python3

# Ransomware decryptor
# This reverses the encryption process from script.py

import sys

alphabet = 'abcdefghijklmnopqrstuvwxyz'

def unshift_chars(text, pos):
    out = ""
    for letter in text:
        if letter in alphabet:
            letter_pos = (alphabet.find(letter) - pos) % 26
            new_letter = alphabet[letter_pos]
            out += new_letter
        else:
            out += letter
    return out

def decrypt_text(text):
    counter = 0
    decrypted_text = ""

    for i in range(0, len(text), 10):
        counter = (counter + 1) % 26
        decrypted_text += unshift_chars(text[i:i+10], counter)
    return decrypted_text

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(f"Usage: {sys.argv[0]} <encrypted_filename>")
        sys.exit(1)
    filename = sys.argv[1]

    if not filename.endswith('.txt'):
        print("Error: File should have .encrypted extension")
        sys.exit(1)

    with open(filename, "r") as f:
        encrypted_data = f.read()

    decrypted_data = decrypt_text(encrypted_data)

    output_filename = filename.replace('.txt', '.decrypted')
    with open(output_filename, "w") as f:
        f.write(decrypted_data)

    print(f"File decrypted successfully to {output_filename}")