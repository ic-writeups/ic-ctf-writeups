#!/usr/bin/env python3

encrypted_flag = bytearray([
  0x15,0x1F,0x12,0x14,0x08,0x10,ord('J'),ord('E'),ord('C'),0x15,
  ord('F'),ord('F'),ord('F'),ord('F'),ord('G'),ord('K'),ord('D'),ord('B'),
  0x15,0x16,0x16,0x17,0x17,ord('D'),0x10,ord('@'),ord('@'),0x12,
  ord('A'),ord('C'),0x15,0x11,ord('D'),ord('@'),ord('J'),ord('B'),
  ord('J'),0x0E,ord('s'),
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
])

xors = [18,43,71,118,102,4,11,54,33,108,55,49,27,91,19,103,67,30,9,39,8,121,75,13,61,82,91]



for i in range(1, 1001):
    key = xors[i % 27]
    for j in range(len(encrypted_flag)):
        encrypted_flag[j] ^= key


flag = encrypted_flag.decode('latin1').split('\x00')[0]
print(f"Decrypted flag: {flag}")


#flag{c960f55554871feedd7c33a20fb73919}