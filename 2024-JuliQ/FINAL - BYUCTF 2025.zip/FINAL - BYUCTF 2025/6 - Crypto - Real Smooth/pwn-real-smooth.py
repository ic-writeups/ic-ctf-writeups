#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# This exploit template was generated via:
# $ pwn template ./real-smooth.py
from pwn import *

# Set up pwntools for the correct architecture
#exe = context.binary = ELF(args.EXE or './real-smooth.py')

# Many built-in settings can be controlled on the command-line and show up
# in "args".  For example, to dump all data sent/received, and disable ASLR
# for all created processes...
# ./exploit.py DEBUG NOASLR



def start(argv=[], *a, **kw):
    '''Start the exploit against the target.'''
    if args.GDB:
        return gdb.debug([exe.path] + argv, gdbscript=gdbscript, *a, **kw)
    else:
        return process([exe.path] + argv, *a, **kw)

# Specify your GDB script here for debugging
# GDB will be launched if the exploit is run via e.g.
# ./exploit.py GDB
gdbscript = '''
continue
'''.format(**locals())

#===========================================================
#                    EXPLOIT GOES HERE
#===========================================================

io = remote("smooth.chal.cyberjousting.com", 1350)
#io = process(["python3", "real-smooth.py"])
#io = start()

P1 = b"Slide to the left"
P2 = b"Slide to the right"

def derive_keystream(c1, p1, c2, p2):
    # c1 = p1 ⊕ ks[0:len(p1)]
    ks1 = bytes(a ^ b for a,b in zip(c1, p1))
    # c2 = p2 ⊕ ks[len(p1):len(p1)+len(p2)]
    ks2 = bytes(a ^ b for a,b in zip(c2, p2))
    return ks1 + ks2

c1 = bytes.fromhex(io.recvline().strip().decode())
c2 = bytes.fromhex(io.recvline().strip().decode())

# recover the keystream prefix
ks = derive_keystream(c1, P1, c2, P2)

TARGET = b"Criss cross, criss cross"


# encrypt under fresh keystream = ks[0:len(TARGET)]
ct3 = bytes(p ^ k for p,k in zip(TARGET, ks))


io.sendline(ct3.hex())
print(io.recvline().decode().strip())
print(io.recvline().decode().strip())
io.close()



