
"""nums = [12838,1089,16029,13761,1276,14790,2091,17199,2223,2925,17901,3159,18135,18837,3135,19071,4095,19773,4797,4085,20007,5733,20709,17005,2601,9620,3192,9724,3127,8125]
flag = ''
for i, n in enumerate(nums, 3):
    flag += chr(n // i)
print(flag)"""


"""numbers = [12838, 1089, 16029, 13761, 1276, 14790, 2091, 17199, 2223, 2925, 17901, 3159, 18135, 18837, 3135, 19071, 4095, 19773, 4797, 4085, 20007, 5733, 20709, 17005, 2601, 9620, 3192, 9724, 3127, 8125]
u, U = 3, 256

# Compute pow(3, i, 256) for i in range(3, 33) (since len(numbers) = 30)
pow_list = [pow(u, i, U) for i in range(u, u + len(numbers))]

# Compute the flag characters
flag = []
for i in range(len(numbers)):
    char_ord = numbers[i] // pow_list[i]
    flag.append(chr(char_ord))

flag = ''.join(flag)
print(flag)"""

"""
from string import printable

target = [
    12838, 1089, 16029, 13761, 1276, 14790, 2091, 17199, 2223, 2925,
    17901, 3159, 18135, 18837, 3135, 19071, 4095, 19773, 4797, 4085,
    20007, 5733, 20709, 17005, 2601, 9620, 3192, 9724, 3127, 8125
]

flag = ""
base = 3

for i in range(len(target)):
    power = base ** i
    for c in printable:
        if ord(c) * power == target[i]:
            flag += c
            break
    else:
        flag += '?'

print("Flag:", flag)

"""
"""
from string import printable

# Given list from the challenge
target = [
    12838, 1089, 16029, 13761, 1276, 14790, 2091, 17199, 2223, 2925,
    17901, 3159, 18135, 18837, 3135, 19071, 4095, 19773, 4797, 4085,
    20007, 5733, 20709, 17005, 2601, 9620, 3192, 9724, 3127, 8125
]

U = 256
base = 3

# Precompute pow(3, i, 256)
powers = [pow(base, i, U) for i in range(len(target))]

flag = ""

# Brute-force each character
for i in range(len(target)):
    found = False
    for c in printable:
        if powers[i] * ord(c) == target[i]:
            flag += c
            found = True
            break
    if not found:
        flag += '?'  # mark unknown if not found

flag

"""
"""from string import printable

# The numbers from u.py
numbers = [12838,1089,16029,13761,1276,14790,2091,17199,2223,2925,17901,3159,18135,18837,3135,19071,4095,19773,4797,4085,20007,5733,20709,17005,2601,9620,3192,9724,3127,8125]

def solve_flag():
    result = ""
    for i in range(len(numbers)):
        p = pow(3, i + 3, 256)  # power of 3 with offset 3
        for c in range(32, 127):  # printable ASCII
            if c * p == numbers[i]:  # direct multiplication check
                result += chr(c)
                break
    return "byu" + result  # add prefix since first 3 chars aren't checked

print(solve_flag())"""