"""
Texto base pero separado en linia por linea
ù,ú,û,ü,ũ,ū,ŭ,ů,ű,ų,ṳ,ṷ,ụ=chr,ord,abs,input,all,print,len,input,pow,range,list,dict,set
ù=[12838,1089,16029,13761,1276,14790,2091,17199,2223,2925,17901,3159,18135,18837,3135,19071,4095,19773,4797,4085,20007,5733,20709,17005,2601,9620,3192,9724,3127,8125]
u,U=3,256
ṷ=ü()
ʉ=ṳ(ụ([ű(u,û,U) for û in(ų(U))]))[u:ŭ(ù)+u]
print (ʉ)
ṳ=zip
print (ṳ)
ṷ=[ú(û) for û in(ṷ)]
assert(ŭ(ù)==ŭ(ṷ))
assert(ũ([û*ü==ū for û,ü,ū in(ṳ(ʉ,ṷ,ù))]))
"""

## Funcion re-escrita y ordenada por chatGPT

chr, ord, abs, input, all, print, len, input, pow, range, list, dict, set = (
    chr, ord, abs, input, all, print, len, input, pow, range, list, dict, set
)

numbers = [12838, 1089, 16029, 13761, 1276, 14790, 2091, 17199, 2223, 2925, 17901, 3159, 18135, 18837, 3135, 19071, 4095, 19773, 4797, 4085, 20007, 5733, 20709, 17005, 2601, 9620, 3192, 9724, 3127, 8125]

u, U = 3, 256

# Get user input
user_input = input()

# Generate a list of numbers from pow(3, i, 256) for i in range(256)
pow_list = list([pow(u, i, U) for i in range(U)])

# Slice the pow_list from index 3 to len(numbers) + 3
sliced_pow = pow_list[u:len(numbers) + u]

# Zip the sliced_pow with user_input and numbers
zipped = zip(sliced_pow, user_input, numbers)

# Convert user_input to a list of ordinals
user_ords = [ord(c) for c in user_input]

# Assertions
assert(len(numbers) == len(user_ords))
assert(all([a * b == c for a, b, c in zipped]))