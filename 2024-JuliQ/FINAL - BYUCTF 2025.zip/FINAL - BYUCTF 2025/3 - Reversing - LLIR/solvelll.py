#!/usr/bin/env python3
import string

# allowed chars
ALPHABET = string.ascii_lowercase + string.digits + "_{}"

# fixed positions from the asm:
# s[0:6] = "byuctf"
# s[6]   = '{'
# s[36]  = '}'
# chain‐equal groups:
#   [4,14,17,23,25]  all == 't'
#   [9,20]          s9 == s20
#   [10,18]         s10 == s18
#   [11,15,24,27,31] all == '_'
#   [13,26]
#   [16,29]
#   [19,28]
# arithmetic:
#   s[8] == ord(s[7]) - 32
#   s[9]+s[20] == ord(s[31]) + 3
#   s[31]+3    == ord(s[0])

TARGET = [None]*37
TARGET[0:6] = list("byuctf")
TARGET[6] = "{"
TARGET[36]= "}"

# pre‐fill known chain groups:
for i in [4,14,17,23,25]:
    TARGET[i] = "t"
for i in [11,15,24,27,31]:
    TARGET[i] = "_"

# and the s31+3 == s0 check gives s31 = chr(ord('b')-3) = '_'
# which we already set.

chains = [
    (9,20),
    (10,18),
    (13,26),
    (16,29),
    (19,28),
]

def ok_partial(s):
    # whenever both positions in a chain are assigned, they must match
    for a,b in chains:
        if s[a] and s[b] and s[a]!=s[b]: return False

    # arithmetic on 7/8:
    if s[7] and s[8]:
        if ord(s[8]) != ord(s[7]) - 32: return False

    # arithmetic on 9+20 == 31+3:
    if s[9] and s[20]:
        lhs = ord(s[9]) + ord(s[20])
        rhs = ord(s[31]) + 3
        if lhs != rhs: return False

    return True

def dfs(pos, s):
    if pos==37:
        flag = "".join(s)
        # verify final arithmetic s31+3 == s0:
        if ord(s[31])+3 != ord(s[0]):
            return
        print("FOUND FLAG: byuctf{{{}}}".format(flag[7:36]))
        exit(0)

    if TARGET[pos]:
        s[pos] = TARGET[pos]
        if ok_partial(s):
            dfs(pos+1, s)
        s[pos] = None
    else:
        for c in ALPHABET:
            s[pos]=c
            if ok_partial(s):
                dfs(pos+1, s)
        s[pos]=None

if __name__=="__main__":
    state = [None]*37
    # copy TARGET
    for i in range(37):
        state[i] = TARGET[i]
    dfs(0, state)
